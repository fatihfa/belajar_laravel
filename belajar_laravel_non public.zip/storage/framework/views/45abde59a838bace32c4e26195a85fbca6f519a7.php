<html>
<head>
	<title>Tutorial Membuat CRUD Pada Laravel - www.malasngoding.com</title>
</head>
<body>
 
	<h2>www.malasngoding.com</h2>
	<h3>Data Pegawai</h3>

 
 
</body>
</html><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/welcome.blade.php ENDPATH**/ ?>